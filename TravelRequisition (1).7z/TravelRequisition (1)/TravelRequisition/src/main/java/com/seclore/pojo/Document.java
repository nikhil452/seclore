package com.seclore.pojo;

public class Document {
	private int documentId;
	private TravelRequest travelRequest;
	private String passport;

	public Document() {
		super();
	}

	public Document(int documentId, TravelRequest travelRequest, String passport) {
		super();
		this.documentId = documentId;
		this.travelRequest = travelRequest;
		this.passport = passport;
	}

	public int getDocumentId() {
		return documentId;
	}

	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}

	public TravelRequest getTravelRequest() {
		return travelRequest;
	}

	public void setTravelRequest(TravelRequest travelRequest) {
		this.travelRequest = travelRequest;
	}

	public String getPassport() {
		return passport;
	}

	public void setPassport(String passport) {
		this.passport = passport;
	}

	@Override
	public String toString() {
		return "Document [documentId=" + documentId + ", travelRequest=" + travelRequest + ", passport=" + passport
				+ "]";
	}

}
