package com.seclore.dao;

import java.util.List;

import com.seclore.pojo.SlabRequest;

public interface SlabRequestDAOInterface 
{
	public boolean addNewSlabRequest(SlabRequest slabRequest);
	
	public List<SlabRequest> getAllSlabRequest();
	
	public boolean updateSlabRequest(int slabId);
}
