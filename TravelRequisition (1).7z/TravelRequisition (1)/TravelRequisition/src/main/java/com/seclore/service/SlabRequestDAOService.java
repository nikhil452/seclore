package com.seclore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.seclore.dao.SlabRequestDAOInterface;
import com.seclore.pojo.SlabRequest;

@Component
public class SlabRequestDAOService implements SlabRequestDAOServiceInterface
{
	@Autowired
	private SlabRequestDAOInterface slabRequestDAO;
	
	public boolean addNewSlabRequest(SlabRequest slabRequest) {
		return slabRequestDAO.addNewSlabRequest(slabRequest);
	}
	
	public List<SlabRequest> getAllSlabRequest(){
		return slabRequestDAO.getAllSlabRequest();
	}
	
	@Override
	public boolean updateSlabRequest(int slabId) {
		return slabRequestDAO.updateSlabRequest(slabId);
	}
}
