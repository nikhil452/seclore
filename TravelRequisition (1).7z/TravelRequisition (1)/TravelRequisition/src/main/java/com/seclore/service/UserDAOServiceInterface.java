package com.seclore.service;

import com.seclore.pojo.User;

public interface UserDAOServiceInterface {
	public User getUserByUserId(int userId);

	public User userLogin(User user);
}
