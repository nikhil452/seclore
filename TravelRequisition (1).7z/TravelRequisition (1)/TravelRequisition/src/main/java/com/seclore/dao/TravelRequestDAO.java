package com.seclore.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.seclore.pojo.TravelRequest;
import com.seclore.pojo.User;
import com.seclore.service.UserDAOServiceInterface;

public class TravelRequestDAO implements TravelRequestDAOInterface {

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private UserDAOServiceInterface userDAOService;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean addNewTravelRequest(TravelRequest travelRequest) {
		String sql = "INSERT INTO request_details VALUES(" + travelRequest.getUser().getUserId() + " , "
				+ travelRequest.getRequestBudget() + " , '" + travelRequest.getSource() + "'  , '"
				+ travelRequest.getDestination() + "' , '" + travelRequest.getRequestStatus() + "');";
		int count = jdbcTemplate.update(sql);
		return count > 0;
	}

	@Override
	public List<TravelRequest> getAllTravelRequestByUser(User user) {
		String sql = "select * from request_details where user_id=?";
		Object[] args = new Object[] { user.getUserId() };
		List<TravelRequest> travelRequests = jdbcTemplate.query(sql, args, new RowMapper<TravelRequest>() {
			@Override
			public TravelRequest mapRow(ResultSet resultSet, int row) throws SQLException {
				TravelRequest travelRequest = new TravelRequest();
				travelRequest.setRequestId(Integer.valueOf(resultSet.getString(1)));
				travelRequest.setUser(user);
				travelRequest.setRequestBudget(Float.valueOf(resultSet.getString(3)));
				travelRequest.setSource(resultSet.getString(4));
				travelRequest.setDestination(resultSet.getString(5));
				travelRequest.setRequestStatus(resultSet.getString(6));
				return travelRequest;
			}
		});
		Collections.reverse(travelRequests);
		return travelRequests;
	}

	public List<TravelRequest> getAllPendingUserTravelRequest(String userType, String status) {
		String sql = "select r.request_id, r.user_id,r.request_budget, r.travel_source,r.travel_destination from request_details r inner join user_details u\r\n"
				+ "on r.user_id = u.user_id AND u.user_type in('"+userType+"') AND request_status='"+status+"'";
		List<TravelRequest> travelRequests = jdbcTemplate.query(sql, new RowMapper<TravelRequest>() {
			@Override
			public TravelRequest mapRow(ResultSet resultSet, int row) throws SQLException {
				TravelRequest travelRequest = new TravelRequest();
				travelRequest.setRequestId(Integer.valueOf(resultSet.getString(1)));
				travelRequest.setUser(userDAOService.getUserByUserId(Integer.valueOf(resultSet.getString(2))));
				travelRequest.setRequestBudget(Float.valueOf(resultSet.getString(3)));
				travelRequest.setSource(resultSet.getString(4));
				travelRequest.setDestination(resultSet.getString(5));
				return travelRequest;
			}
		});
		Collections.reverse(travelRequests);
		return travelRequests;
	}
	
	public boolean updateUserTravelRequest(int requestId, String status) {
		String sql = "UPDATE request_details SET request_status='"+status+"' WHERE request_id="+requestId+"";
		int count = jdbcTemplate.update(sql);
		return count > 0;
	}
	
	public TravelRequest getTravelRequestByTravelRequestId(int travelRequestId) {
		String sql = "select * from request_details where request_id=?";
		Object[] args = new Object[] { travelRequestId };
		TravelRequest travelRequest = jdbcTemplate.queryForObject(sql, args, new RowMapper<TravelRequest>() {
			@Override
			public TravelRequest mapRow(ResultSet resultSet, int row) throws SQLException {
				TravelRequest travelRequest = new TravelRequest();
				travelRequest.setRequestId(Integer.valueOf(resultSet.getString(1)));
				travelRequest.setUser(userDAOService.getUserByUserId(Integer.valueOf(resultSet.getString(2))));
				travelRequest.setRequestBudget(Float.valueOf(resultSet.getString(3)));
				travelRequest.setSource(resultSet.getString(4));
				travelRequest.setDestination(resultSet.getString(5));
				travelRequest.setRequestStatus(resultSet.getString(6));
				return travelRequest;
			}
		});
		return travelRequest;
	}
	
	public boolean updateTravelRequestBudget(int requestId, float newBudget) {
		String sql = "UPDATE request_details SET request_budget="+newBudget+" WHERE request_id="+requestId+"";
		int count = jdbcTemplate.update(sql);
		return count > 0;
	}
}
