package com.seclore.service;

import java.util.List;

import com.seclore.pojo.SlabRequest;

public interface SlabRequestDAOServiceInterface {
	public boolean addNewSlabRequest(SlabRequest slabRequest);

	public List<SlabRequest> getAllSlabRequest();
	
	public boolean updateSlabRequest(int slabId);
}
