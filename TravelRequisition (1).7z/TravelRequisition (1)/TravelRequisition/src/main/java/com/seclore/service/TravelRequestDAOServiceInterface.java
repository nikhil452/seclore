package com.seclore.service;

import java.util.List;

import com.seclore.pojo.TravelRequest;
import com.seclore.pojo.User;

public interface TravelRequestDAOServiceInterface {
	public boolean addNewTravelRequest(TravelRequest travelRequest);

	public List<TravelRequest> getAllTravelRequestByUser(User user);
	
	public List<TravelRequest> getAllPendingUserTravelRequest(String userType, String status);
	
	public boolean updateUserTravelRequest(int requestId, String status);
	
	public TravelRequest getTravelRequestByTravelRequestId(int travelRequestId);
	
	public boolean updateTravelRequestBudget(int requestId, float newBudget);
}
