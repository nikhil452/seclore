package com.seclore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.seclore.dao.UserDAOInterface;
import com.seclore.pojo.User;

@Component
public class UserDAOService implements UserDAOServiceInterface {
	@Autowired
	private UserDAOInterface userDAO;

//	public UserDAOInterface getUserDAO() {
//		return userDAO;
//	}
//
//	public void setUserDAO(UserDAOInterface userDAO) {
//		this.userDAO = userDAO;
//	}

	@Override
	public User userLogin(User user) {
		return userDAO.userLogin(user);
	}

	@Override
	public User getUserByUserId(int userId) {
		return userDAO.getUserByUserId(userId);
	}
}
