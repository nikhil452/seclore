package com.seclore.pojo;

public class TravelRequest {
	private int requestId;
	private User user;
	private float requestBudget;
	private String requestStatus;
	private String source;
	private String destination;
	

	public TravelRequest() {
		super();
	}


	public TravelRequest(int requestId, User user, float requestBudget, String requestStatus, String source,
			String destination) {
		super();
		this.requestId = requestId;
		this.user = user;
		this.requestBudget = requestBudget;
		this.requestStatus = requestStatus;
		this.source = source;
		this.destination = destination;
	}


	public int getRequestId() {
		return requestId;
	}


	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public float getRequestBudget() {
		return requestBudget;
	}


	public void setRequestBudget(float requestBudget) {
		this.requestBudget = requestBudget;
	}


	public String getRequestStatus() {
		return requestStatus;
	}


	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}


	@Override
	public String toString() {
		return "TravelRequest [requestId=" + requestId + ", user=" + user + ", requestBudget=" + requestBudget
				+ ", requestStatus=" + requestStatus + ", source=" + source + ", destination=" + destination + "]";
	}
	
	
}
