package com.seclore.pojo;

import java.sql.Date;

public class Booking {
	private int bookingId;
	private TravelRequest travelRequest;
	private Date travelDate;
	private Date returnDate;

	public Booking() {
		super();
	}

	public Booking(int bookingId, TravelRequest travelRequest, Date travelDate, Date returnDate) {
		super();
		this.bookingId = bookingId;
		this.travelRequest = travelRequest;
		this.travelDate = travelDate;
		this.returnDate = returnDate;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public TravelRequest getTravelRequest() {
		return travelRequest;
	}

	public void setTravelRequest(TravelRequest travelRequest) {
		this.travelRequest = travelRequest;
	}

	public Date getTravelDate() {
		return travelDate;
	}

	public void setTravelDate(Date travelDate) {
		this.travelDate = travelDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", travelRequest=" + travelRequest + ", travelDate=" + travelDate
				+ ", returnDate=" + returnDate + "]";
	}

}
