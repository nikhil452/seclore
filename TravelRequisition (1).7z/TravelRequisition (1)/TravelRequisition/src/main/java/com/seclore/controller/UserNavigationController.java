package com.seclore.controller;

import java.net.http.HttpRequest;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.seclore.pojo.SlabRequest;
import com.seclore.pojo.TravelRequest;
import com.seclore.pojo.User;
import com.seclore.service.SlabRequestDAOServiceInterface;
import com.seclore.service.TravelRequestDAOServiceInterface;

@Controller
@RequestMapping("/User")
public class UserNavigationController {

	@Autowired
	private TravelRequestDAOServiceInterface travelRequestDAOService;
	
	@Autowired
	private SlabRequestDAOServiceInterface slabRequestDAOService;

	@RequestMapping("EmployeeDashboardPage")
	public String employeeDashboardPage(HttpServletRequest httpRequest, Model model) {
		User user = (User) httpRequest.getSession().getAttribute("User");
		if (user.getUserName() != null) {
			model.addAttribute("travelRequestList", travelRequestDAOService.getAllTravelRequestByUser(user));
			return "employeeDashboardPage";
		} else {
			return "redirect:/";
		}
	}

	@RequestMapping("ManagerDashboardPage")
	public String managerDashboardPage(HttpServletRequest httpRequest, Model model) {
		User user = (User) httpRequest.getSession().getAttribute("User");
		if (user.getUserName() != null) {
			model.addAttribute("travelRequestList", travelRequestDAOService.getAllTravelRequestByUser(user));
			model.addAttribute("employeeTravelRequestList",
					travelRequestDAOService.getAllPendingUserTravelRequest("Employee", "Pending At ProjectManager"));
			return "managerDashboardPage";
		} else {
			return "redirect:/";
		}
	}

	@RequestMapping("DirectorDashboardPage")
	public String directorDashboardPage(HttpServletRequest httpRequest, Model model) {
		User user = (User) httpRequest.getSession().getAttribute("User");
		if (user.getUserName() != null) {
			model.addAttribute("managerTravelRequestList",
					travelRequestDAOService.getAllPendingUserTravelRequest("ProjectManager", "Pending At Director"));
			model.addAttribute("slabRequestList",slabRequestDAOService.getAllSlabRequest());
			return "directorDashboardPage";
		} else {
			return "redirect:/";
		}
	}

	@RequestMapping("AgentDashboardPage")
	public String agentDashboardPage(HttpServletRequest httpRequest, Model model) {
		User user = (User) httpRequest.getSession().getAttribute("User");
		if (user.getUserName() != null) {
			model.addAttribute("travelRequestList", travelRequestDAOService
					.getAllPendingUserTravelRequest("Employee','ProjectManager", "Pending At TravelAgent"));
			return "agentDashboardPage";
		} else {
			return "redirect:/";
		}
	}

	@RequestMapping("TravelRequestPage")
	public String travelRequestPage(HttpServletRequest httpRequest, Model model) {
		User user = (User) httpRequest.getSession().getAttribute("User");
		TravelRequest travelRequest = new TravelRequest();
		if (user.getUserType().equals("Employee")) {
			travelRequest.setRequestBudget(10000);
			travelRequest.setRequestStatus("Pending At ProjectManager");
		} else {
			travelRequest.setRequestBudget(15000);
			travelRequest.setRequestStatus("Pending At Director");
		}
		model.addAttribute("travelRequest", travelRequest);
		return "travelRequestPage";
	}

	@RequestMapping("CreateNewTravelRequest")
	public String createNewTravelRequest(@ModelAttribute("travelRequest") TravelRequest travelRequest,
			HttpServletRequest httpRequest) {
		User user = (User) httpRequest.getSession().getAttribute("User");
		travelRequest.setUser(user);
		travelRequestDAOService.addNewTravelRequest(travelRequest);
		return "redirect:/SubmitLogin";
	}

	@RequestMapping("ApproveTravelRequest/{requestId}")
	public String approveTravelRequest(@PathVariable int requestId, HttpServletRequest httpRequest) {
		travelRequestDAOService.updateUserTravelRequest(requestId, "Pending At TravelAgent");
		return "redirect:/SubmitLogin";
	}
	
	@RequestMapping("UpdateBudget/{requestId}/{slabId}/{newBudget}")
	public String updateBudget(@PathVariable int slabId,@PathVariable int requestId,@PathVariable float newBudget , HttpServletRequest httpRequest) {
		travelRequestDAOService.updateTravelRequestBudget(requestId, newBudget);
		slabRequestDAOService.updateSlabRequest(slabId);
		travelRequestDAOService.updateUserTravelRequest(requestId, "Pending At TravelAgent");
		return "redirect:/SubmitLogin";
	}
	
	@RequestMapping("FinalApproveTravelRequest/{requestId}")
	public String finalApproveTravelRequest(@PathVariable int requestId, HttpServletRequest httpRequest) {
		travelRequestDAOService.updateUserTravelRequest(requestId, "Final Approved");
		return "redirect:/SubmitLogin";
	}

	@RequestMapping("RejectTravelRequest/{requestId}")
	public String rejectTravelRequest(@PathVariable int requestId, HttpServletRequest httpRequest) {
		User user = (User) httpRequest.getSession().getAttribute("User");
		travelRequestDAOService.updateUserTravelRequest(requestId, "Rejected By " + user.getUserType());
		return "redirect:/SubmitLogin";
	}

	@RequestMapping("IncreaseSlabRequestPage/{requestId}")
	public String increaseSlabRequest(@PathVariable int requestId, HttpServletRequest httpRequest, Model model) {
		model.addAttribute("slabRequest",
				new SlabRequest(0, travelRequestDAOService.getTravelRequestByTravelRequestId(requestId), 0,""));
		return "increaseSlabRequestPage";
	}
	
	@RequestMapping("CreateNewSlabRequest/{requestId}")
	public String createNewTravelRequest(@PathVariable int requestId,@ModelAttribute("slabRequest") SlabRequest slabRequest,
			HttpServletRequest httpRequest) {
		slabRequest.setTravelRequest(travelRequestDAOService.getTravelRequestByTravelRequestId(requestId));
		travelRequestDAOService.updateUserTravelRequest(requestId, "Pending At Director For Slab Increase");
		slabRequestDAOService.addNewSlabRequest(slabRequest);
		return "redirect:/SubmitLogin";
	}
}
