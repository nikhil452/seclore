package com.seclore.dao;

import com.seclore.pojo.User;

public interface UserDAOInterface 
{
	public User getUserByUserId(int userId);
	
	public User userLogin(User user);
}
