package com.seclore.dao;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.seclore.pojo.User;

public class UserDAO implements UserDAOInterface {
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public User userLogin(User user) {
		try {
			String sql = "select * from user_details where user_id=? and user_password=?";
			Object[] args = new Object[] { user.getUserId(), user.getUserPassword() };
			User loggedUser = jdbcTemplate.queryForObject(sql, args, new BeanPropertyRowMapper<User>(User.class));
			return loggedUser;
		} catch (Exception e) {
			return null;
		}
	}

	public User getUserByUserId(int userId) {
		String sql = "select * from user_details where user_id=?";
		Object[] args = new Object[] { userId };
		User user = jdbcTemplate.queryForObject(sql, args, new BeanPropertyRowMapper<User>(User.class));
		return user;
	}
}
