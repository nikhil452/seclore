package com.seclore.pojo;

public class SlabRequest {
	private int slabId;
	private TravelRequest travelRequest;
	private float slabNewBudget;
	private String slabRequestStatus;

	public SlabRequest() {
		super();
	}

	public SlabRequest(int slabId, TravelRequest travelRequest, float slabNewBudget, String slabRequestStatus) {
		super();
		this.slabId = slabId;
		this.travelRequest = travelRequest;
		this.slabNewBudget = slabNewBudget;
		this.slabRequestStatus = slabRequestStatus;
	}

	public int getSlabId() {
		return slabId;
	}

	public void setSlabId(int slabId) {
		this.slabId = slabId;
	}

	public TravelRequest getTravelRequest() {
		return travelRequest;
	}

	public void setTravelRequest(TravelRequest travelRequest) {
		this.travelRequest = travelRequest;
	}

	public float getSlabNewBudget() {
		return slabNewBudget;
	}

	public void setSlabNewBudget(float slabNewBudget) {
		this.slabNewBudget = slabNewBudget;
	}
	
	public String getSlabRequestStatus() {
		return slabRequestStatus;
	}

	public void setSlabRequestStatus(String slabRequestStatus) {
		this.slabRequestStatus = slabRequestStatus;
	}

	@Override
	public String toString() {
		return "SlabRequest [slabId=" + slabId + ", travelRequest=" + travelRequest + ", slabNewBudget=" + slabNewBudget
				+ ", slabRequestStatus=" + slabRequestStatus + "]";
	}

}
