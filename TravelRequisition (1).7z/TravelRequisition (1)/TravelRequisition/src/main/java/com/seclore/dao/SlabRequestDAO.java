package com.seclore.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.seclore.pojo.SlabRequest;
import com.seclore.pojo.TravelRequest;
import com.seclore.pojo.User;
import com.seclore.service.TravelRequestDAOServiceInterface;

@Component
public class SlabRequestDAO implements SlabRequestDAOInterface {

	private JdbcTemplate jdbcTemplate;

	@Autowired
	private TravelRequestDAOServiceInterface travelRequestDAOService;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean addNewSlabRequest(SlabRequest slabRequest) {
		String sql = "INSERT INTO slab_details VALUES(" + slabRequest.getTravelRequest().getRequestId() + " , "
				+ slabRequest.getSlabNewBudget() +",'"+ slabRequest.getSlabRequestStatus()+"');";
		int count = jdbcTemplate.update(sql);
		return count > 0;
	}

	public List<SlabRequest> getAllSlabRequest() {
		String sql = "select s.slab_id, s.request_id, s.slab_new_budget from slab_details s inner join request_details r\r\n"
				+ "on s.request_id=r.request_id\r\n"
				+ "where r.request_status='Pending At Director For Slab Increase' AND slab_request_status = 'Active';";
		List<SlabRequest> slabRequests = jdbcTemplate.query(sql, new RowMapper<SlabRequest>() {
			@Override
			public SlabRequest mapRow(ResultSet resultSet, int row) throws SQLException {
				SlabRequest slabRequest = new SlabRequest();
				slabRequest.setSlabId(Integer.valueOf(resultSet.getString(1)));
				slabRequest.setTravelRequest(travelRequestDAOService
						.getTravelRequestByTravelRequestId(Integer.valueOf(resultSet.getString(2))));
				slabRequest.setSlabNewBudget(Float.valueOf(resultSet.getString(3)));
				return slabRequest;
			}
		});
		Collections.reverse(slabRequests);
		return slabRequests;
	}
	
	public boolean updateSlabRequest(int slabId) {
		String sql = "UPDATE slab_details SET slab_request_status='Inactive' where slab_id="+slabId+"";
		int count = jdbcTemplate.update(sql);
		return count > 0;
	}

}
