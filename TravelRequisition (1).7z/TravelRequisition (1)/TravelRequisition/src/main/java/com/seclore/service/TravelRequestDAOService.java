package com.seclore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.seclore.dao.TravelRequestDAOInterface;
import com.seclore.pojo.TravelRequest;
import com.seclore.pojo.User;

@Component
public class TravelRequestDAOService implements TravelRequestDAOServiceInterface {

	@Autowired
	private TravelRequestDAOInterface travelRequestDAO;

	@Override
	public boolean addNewTravelRequest(TravelRequest travelRequest) {
		return travelRequestDAO.addNewTravelRequest(travelRequest);
	}
	
	@Override
	public List<TravelRequest> getAllTravelRequestByUser(User user) {
		return travelRequestDAO.getAllTravelRequestByUser(user);
	}
	
	@Override
	public List<TravelRequest> getAllPendingUserTravelRequest(String userType, String status) {
		return travelRequestDAO.getAllPendingUserTravelRequest(userType, status);
	}
	
	@Override
	public boolean updateUserTravelRequest(int requestId, String status) {
		return travelRequestDAO.updateUserTravelRequest(requestId, status);
	}
	
	@Override
	public TravelRequest getTravelRequestByTravelRequestId(int travelRequestId) {
		return travelRequestDAO.getTravelRequestByTravelRequestId(travelRequestId);
	}
	
	@Override
	public boolean updateTravelRequestBudget(int requestId, float newBudget) {
		return travelRequestDAO.updateTravelRequestBudget(requestId, newBudget);
	}

}
