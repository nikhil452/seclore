package com.seclore.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.seclore.pojo.User;
import com.seclore.service.UserDAOServiceInterface;

@Controller
public class LoginPageController {
	@Autowired
	private UserDAOServiceInterface userDAOService;

	@RequestMapping("/")
	public String loginPage(Model model) {
		model.addAttribute("User", new User());
		return "loginPage";
	}
	
	@RequestMapping("Logout")
	public String logOut(HttpServletRequest httpRequest) {
		httpRequest.getSession().invalidate();
		return "redirect:/";
	}

	@RequestMapping("SubmitLogin")
	public String submitLogin(@ModelAttribute("User") User unauthenticateUser, HttpServletRequest httpRequest) {
		User user;
		if(httpRequest.getSession().getAttribute("User")==null) {
			user = userDAOService.userLogin(unauthenticateUser);
			httpRequest.getSession().setAttribute("User", user);
			}
		else {
			user=(User) httpRequest.getSession().getAttribute("User");
		}
		if (user != null) {
			String loggedUserType = user.getUserType();
			if (loggedUserType.equals("Employee")) {
				return "redirect:/User/EmployeeDashboardPage";

			} else if (loggedUserType.equals("ProjectManager")) {
				return "redirect:/User/ManagerDashboardPage";

			} else if (loggedUserType.equals("Director")) {
				return "redirect:/User/DirectorDashboardPage";

			} else {
				return "redirect:/User/AgentDashboardPage";
			}

		} else {
			httpRequest.getSession().setAttribute("message", "Invalid Id or Password");
			return "redirect:/";
		}
	}
}
